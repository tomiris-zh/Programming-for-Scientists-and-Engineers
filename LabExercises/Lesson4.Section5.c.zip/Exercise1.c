#include<stdio.h>
#include<math.h>

int main(void) {

 int m;

    scanf("%i", &m );
    printf("In 1 meter centimeters %d, myriameters %d, inches %f, miles %f, furlongs %f", m*100 , m*10000, m*39.07, m*0.0006214, m*0.004972);





return 0;
}
