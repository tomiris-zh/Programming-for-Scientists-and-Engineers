#include<stdio.h>
#include<math.h>
#include<stdlib.h>

int main(void) {

printf("%i", 1000000000);
return 0;
}
