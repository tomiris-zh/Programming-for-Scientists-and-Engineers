#include <stdio.h>
#include <math.h>

int main() {

    for (int i = -50; i<=40; i++){
            printf("%i Celsius equals to %i Farenheit\n", i, (i*9)/5+32);

    }
    return 0;
}
