#include <stdio.h>
#include <stdlib.h>

int main (){
    printf(".--.     /\                ____\n'--'    /__\    (^._.^)~ <(o.o )>");
    return 0;
}
