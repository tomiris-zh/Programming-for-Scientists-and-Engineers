#include <stdio.h>
#include <stdlib.h>

int main (){
    double r=76;
    printf("if r=%f, then circumference=%f, and area=%f", r, r*2*3.14, 3.14*r*r);
    return 0;
}
